This folder primarily contains third-party libraries; MIT/Apache2.0 licenced.

Most the files are superficially needed and not required for the core function of VDO.Ninja; most anyways.