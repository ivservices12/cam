https://uxwing.com/collapse-icon/
https://uxwing.com/expand-icon/